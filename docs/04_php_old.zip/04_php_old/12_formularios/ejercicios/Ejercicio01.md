---
id: formularios-xss-001
titulo: "Página de producto de una tienda"
tema: "formularios"
orden: 1
icon: "fa-solid fa-cart-shopping"
solucion: "/soluciones/Ejercicio01/index.php"
---


<Color>Enunciado</Color>

Crea una página web que simule una tienda online.

- Muestra un producto con su imagen y precio.
- Incluye una caja de texto para escribir un comentario.
- Al pulsar el botón **Publicar**, el comentario debe aparecer debajo de la imagen del producto.
- Puedes usar la imagen:
<figure style="text-align: center;">
  <img
    src="./images/xss_cascos.jpeg"
    alt="Diagrama de xss_cascos.jpeg"
    width="50px"
  />
  <figcaption>
    Imagen generada con IA (OpenAI, ChatGPT).
  </figcaption>
</figure>


