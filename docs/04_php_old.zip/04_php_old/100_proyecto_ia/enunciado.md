# Laboratorio de IA con PHP

El directorio de trabajo solo contiene las reglas del proyecto. Esta propuesta no crea carpetas, archivos ni código. La implementación empezará únicamente por la fase que autorices.

## 1. Resumen funcional

La aplicación se llama **Laboratorio de IA**. Es un sitio de varias páginas en el que el alumno prueba, con formularios, tres usos de un mismo modelo de chat:

- **Inicio.** Presenta el laboratorio y enlaza con cada experimento mediante tarjetas.
- **Consulta.** Envía una pregunta y muestra una única respuesta.
- **Conversación.** Mantiene los mensajes recientes en la sesión PHP y permite borrar el historial.
- **Taller de texto.** El alumno elige una tarea cerrada (resumir, traducir o corregir), pega un texto y recibe el resultado. La tarea sale de una lista fija del servidor; el alumno no escribe las instrucciones internas del modelo.

La generación de imágenes queda fuera de esta propuesta: exige otro endpoint, otro formato y otro coste. Se podrá plantear como ampliación cuando el chat ya funcione.

El navegador nunca recibe la clave ni llama a la API. Cada respuesta visible pasa por `htmlspecialchars()` antes de pintarse.

## 2. Arquitectura

Tres piezas, con una sola puerta de entrada. El directorio público del servidor será `public/`, así `config/` y `src/` no se pueden pedir por URL.

```mermaid
flowchart LR
  navegador[Navegador]
  indice[public_index.php]
  controlador[Controlador]
  servicio[ChatService]
  apiRemota[API_de_chat]
  vista[Vista]
  configuracion[config.php]

  navegador -->|GET o POST| indice
  indice --> controlador
  controlador --> configuracion
  controlador --> servicio
  servicio -->|HTTPS y JSON| apiRemota
  apiRemota -->|JSON| servicio
  servicio --> controlador
  controlador --> vista
  vista --> navegador
```

- `public/index.php` lee el parámetro `pagina`, lo contrasta con una lista blanca (`inicio`, `consulta`, `conversacion`, `taller`) y crea el controlador correspondiente. Un valor desconocido vuelve al inicio.
- El controlador valida el formulario, llama al servicio si hace falta y prepara un array `$datos` para la vista.
- `ChatService` es la única clase que usa cURL. Los tres experimentos la reutilizan. No habrá un cliente genérico ni varias estrategias de proveedor.
- La vista muestra variables, recorre arrays y escribe condiciones sencillas. No hace HTTP ni lee la configuración.
- Las clases llevan nombre técnico en inglés (`ChatService`, `HomeController`). Las variables, las funciones y los textos de la interfaz van en español.
- Las clases se cargan con `require_once` en un archivo visible, `src/cargar.php`. No se usa Composer ni autocarga.
- Las vistas reciben el array `$datos` y leen claves concretas, por ejemplo `$datos['respuesta']`. Así se ve de dónde sale cada valor.

Figura para el enunciado: recorrido de una consulta válida y de un fallo de validación o de HTTP.

```mermaid
flowchart TD
  formulario[Formulario_POST]
  validar[Validar_longitud_y_vacio]
  preparar[Preparar_mensajes]
  curlNodo[Enviar_cURL]
  interpretar[Interpretar_JSON]
  pintar[Escapar_y_mostrar]
  alerta[Mostrar_alerta]

  formulario --> validar
  validar -->|texto_no_valido| alerta
  validar -->|texto_valido| preparar
  preparar --> curlNodo
  curlNodo -->|sin_respuesta_o_HTTP_de_error| alerta
  curlNodo -->|HTTP_200| interpretar
  interpretar -->|falta_el_texto| alerta
  interpretar -->|texto_encontrado| pintar
```

## 3. Árbol de directorios

Los archivos aparecen en la fase indicada. La fase 1 no crea el servicio ni la configuración de la clave.

```text
public/
  index.php                 fase 1, se amplía al añadir páginas
  assets/                   reservada; la fase 1 no necesita archivos propios
src/
  cargar.php                fase 1
  funciones.php             fase 1
  Controllers/
    HomeController.php      fase 1
    PromptController.php    fase 2
    ConversationController.php  fase 4
    TextTaskController.php  fase 5
  Services/
    ChatService.php         fase 3
views/
  layout.php                fase 1
  inicio.php                fase 1
  consulta.php              fase 2
  conversacion.php          fase 4
  taller.php                fase 5
  parciales/
    navegacion.php          fase 1
    alerta.php              fase 2
config/
  config.ejemplo.php        fase 3, sí se versiona
  config.php                fase 3, queda fuera de Git
docker-compose.yml          fase 0
Dockerfile                  fase 0
.gitignore                  fase 0
README.md                   fase 0
docs/                       enunciado, cuando se pida redactarlo
```

## 4. Responsabilidad de los archivos principales

- `public/index.php`: arranca la sesión cuando la página lo necesita, carga las clases y elige el controlador según `pagina`.
- `src/cargar.php`: lista los `require_once` del proyecto para que se vea qué archivos existen.
- `src/funciones.php`: `e()` envuelve `htmlspecialchars()` y `mostrarVista()` incorpora el layout y la plantilla recibiendo `$datos`.
- `src/Controllers/HomeController.php`: prepara el título y las tarjetas de los experimentos.
- `src/Controllers/PromptController.php`: lee el POST, valida la pregunta y pide una respuesta al servicio.
- `src/Controllers/ConversationController.php`: guarda y recupera el historial en `$_SESSION` y ofrece vaciarlo.
- `src/Controllers/TextTaskController.php`: comprueba que la tarea elegida esté en la lista permitida y monta los mensajes.
- `src/Services/ChatService.php`: construye el JSON, envía cURL, comprueba el código HTTP, decodifica la respuesta y devuelve al controlador un array con `correcto`, `texto` y `error`. El cuerpo crudo de la API no llega a la vista. Un bloque plegable podrá mostrar, en la fase 3, la estructura ya interpretada para explicar el JSON.
- `views/layout.php`: documento HTML, cabecera DaisyUI, `navegacion.php` y el hueco de cada página.
- `views/parciales/alerta.php`: alerta DaisyUI reutilizada por los errores de validación y de API.
- `config/config.ejemplo.php`: plantilla con la URL, el nombre del modelo, el tiempo máximo de espera y el tope de respuesta, sin clave real.
- `config/config.php`: copia local de esa plantilla con la clave. Solo lo lee el servicio.
- `Dockerfile` y `docker-compose.yml`: PHP 8.4 con Apache, cURL y HTTPS, publicando el sitio con raíz en `public/`. La imagen no incluye `config.php`.
- `.gitignore`: excluye `config/config.php`.
- `README.md`: cómo arrancar el entorno y dónde colocar la clave, en español y en pocas líneas.

## 5. Integración con la API

Recomendación para el servicio: **Chat Completions de OpenAI**, porque la clave viaja en la cabecera `Authorization` y no en la URL.

- Método y URL documentados: `POST https://api.openai.com/v1/chat/completions`.
- Cuerpo JSON: el modelo, el array `messages` con `role` y `content`, y el tope de tokens de salida con el nombre de parámetro que indique la documentación del modelo elegido.
- Respuesta de éxito documentada: el texto está en `choices[0].message.content`.
- Respuesta de error documentada: el mensaje está en `error.message`, junto con el código HTTP.
- La verificación TLS permanece activa.
- cURL tendrá un tiempo de espera finito, definido en la configuración.
- El formulario rechazará texto vacío y texto que supere un máximo razonable antes de llamar a la API.
- El nombre del modelo no se fija en esta propuesta. En el momento de implementar se consultará el [listado oficial de modelos](https://developers.openai.com/api/docs/models) y se elegirá un modelo pequeño vigente. `gpt-4o-mini` sigue existiendo, pero figura como modelo con retirada anunciada; no conviene dejarlo escrito para los alumnos sin esa comprobación.
- No se usará el SDK oficial. No se inventarán campos: el cuerpo y la lectura del JSON se contrastarán con la referencia de [Create chat completion](https://developers.openai.com/api/reference/resources/chat) al escribir `ChatService`.

La conversación enviará el historial de la sesión como `messages`. El taller añadirá un primer mensaje `system` elegido en el servidor según la tarea.

Si el centro no puede usar OpenAI, la estructura de carpetas se mantiene, pero hay que cerrar el otro proveedor antes de escribir el servicio. Cambian la URL, la cabecera y la ruta del texto dentro del JSON, y eso es precisamente lo que los alumnos tienen que leer con calma.

## 6. Configuración segura de las claves

- La clave vive en `config/config.php`, fuera de `public/` y fuera de Git.
- `config/config.ejemplo.php` muestra las claves del array con un valor vacío y se puede compartir.
- El servicio es el único código que lee `api_clave`. Ni los controladores ni las vistas la reciben.
- Los mensajes de error de la interfaz explican el problema (falta la clave, la API rechazó la petición, se agotó el tiempo) y no muestran la clave, el cuerpo interno ni la traza.
- Cada alumno crea su `config.php` en su máquina. El repositorio común no lleva ninguna clave, tampoco una clave de aula.
- Con Docker, el archivo se monta en el contenedor o se crea al arrancar; no se copia dentro de la imagen.
- El README indicará que la raíz del servidor es `public/`. Con el servidor incorporado de PHP se usará `php -S localhost:8080 -t public`.

## 7. Interfaz

Tailwind CSS 4 y DaisyUI 5 se cargarán desde la CDN oficial, sin Node ni paso de compilación, tal como documenta [DaisyUI para proyectos sin Node](https://daisyui.com/docs/cdn/):

- hoja `https://cdn.jsdelivr.net/npm/daisyui@5`
- script `https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4`

La interfaz usará componentes DaisyUI: `navbar`, `card`, `textarea`, `select`, `btn`, `alert`, `chat` y `footer`. Las páginas de experimento comparten el layout. La espera de la API es la espera normal del envío del formulario, visible porque el navegador no recarga hasta recibir la respuesta de PHP.

## 8. Fases y conocimientos de PHP

**Fase 0. Entorno.** Docker con PHP 8.4, raíz en `public/`, `.gitignore` y README. Se comprueba que una página mínima se abre en el navegador. Conocimientos: dónde vive un proyecto PHP y qué significa que un archivo sea público.

**Fase 1. Interfaz del laboratorio.** Layout, navegación e inicio con tarjetas. Conocimientos: `require`, funciones, arrays asociativos y la sintaxis alternativa de las vistas.

**Fase 2. Formulario de consulta, todavía sin API.** El POST se valida, el campo conserva el texto y los errores usan la alerta. Conocimientos: `$_POST`, condiciones, funciones de validación y `htmlspecialchars()`.

**Fase 3. Primera llamada.** Configuración local, `ChatService` y la respuesta pintada en la consulta. Conocimientos: clases, cURL, `json_encode` y `json_decode`, arrays anidados, códigos HTTP y excepciones o fallos de cURL convertidos en un mensaje claro.

**Fase 4. Conversación.** Historial breve en sesión y acción de vaciarlo. Conocimientos: `session_start()`, arrays de arrays y diferencia entre datos de un envío y datos guardados en el servidor.

**Fase 5. Taller de texto.** Misma clase de servicio, otra página y una lista blanca de tareas. Conocimientos: `switch` o condiciones sobre un valor permitido y reutilización de una clase.

Cada fase termina con un resumen de cambios, el modo de probarla y los conceptos usados. No se adelantan archivos de fases posteriores.

## 9. Dificultades técnicas y didácticas

- El JSON de éxito y el JSON de error no tienen la misma forma. Conviene mostrar en clase las dos respuestas con datos de ejemplo antes de escribir el `if`.
- Un fallo de red, un HTTP 401 y un JSON sin `choices` son tres casos distintos. Si se mezclan, el alumno solo ve un aviso genérico y no aprende a localizar el problema.
- Si la raíz del servidor es la carpeta del proyecto, `config.php` se puede descargar. Hay que comprobar la URL de la clave y ver que responde como no encontrada.
- La salida del modelo se trata como texto. Escaparla evita que un HTML devuelto por la API se ejecute en la página.
- La sesión debe iniciarse antes de cualquier HTML. El layout no puede imprimirse antes de guardar el historial.
- La CDN pide conexión a Internet en el aula. Si un aula no tiene salida, esta decisión de interfaz hay que cambiarla antes de la fase 1.
- Sin un tope de tokens y sin un máximo de caracteres, una prueba de clase puede consumir crédito de más.
- El coste y el alta de la cuenta del proveedor son una barrera de aula más grande que el propio PHP. Conviene resolverla antes de la fase 3.
- Docker facilita tener PHP 8.4 igual para todos y, a la vez, añade conceptos nuevos. El README tendrá que separar “arrancar el contenedor” de “entender el controlador”.

## 10. Decisiones a cerrar antes de implementar

1. **Proveedor.** Se recomienda OpenAI Chat Completions. Si el centro usa otra API de chat, hay que nombrarla antes de la fase 3. La estructura de carpetas puede aprobarse igual.
2. **Modelo, tope de tokens y quién aporta la clave.** Se elegirá un modelo pequeño vigente al implementar, con un límite de salida bajo.
3. **Entorno.** Se recomienda Docker con PHP 8.4 y Apache. La alternativa es PHP 8.4 instalado en cada equipo y `php -S -t public`.
4. **Estilos.** Se recomienda la CDN de DaisyUI 5 y Tailwind 4, aceptando que el aula necesita Internet.
5. **Alcance de la primera autorización.** Se recomienda construir solo las fases 0 y 1, revisarlas en el navegador y esperar una nueva autorización para el formulario y para cURL.
6. **Enunciado del alumnado.** No forma parte de esta autorización. Cuando lo pidas, se redactará en `docs/` por fases, en español, sin la solución completa, e incluirá las dos figuras de esta propuesta.**