# Proyecto docente: Construye tu propio asistente de IA con PHP y Docker

Actúa como un profesor experto en Desarrollo Web en Entorno Servidor (DWES), desarrollador senior de PHP y especialista en diseño de prácticas educativas de Formación Profesional.

Quiero que me ayudes a **diseñar, desarrollar, documentar y validar una práctica completa y motivadora** para mis alumnos de DWES.

No quiero que generes todo el proyecto de golpe. Trabajaremos de manera incremental, tomando decisiones y validando cada fase antes de continuar.

## 1. Contexto docente

Los alumnos están aprendiendo desarrollo web en entorno servidor con PHP.

Conocen o habrán trabajado:

- Variables, operadores y estructuras de control.
- Funciones.
- Arrays indexados, asociativos y multidimensionales.
- Formularios HTML y métodos GET y POST.
- Separación entre lógica de procesamiento y presentación.
- Programación orientada a objetos.
- Sesiones PHP.
- Fundamentos de HTTP.
- Docker y Docker Compose.

La práctica debe servir para introducir y consolidar:

- Servicios web y APIs REST.
- Consumo de APIs mediante PHP y cURL.
- Intercambio de información mediante JSON.
- Gestión de errores HTTP.
- Integración de servicios externos.
- Desarrollo de una aplicación web estructurada.

No utilizaremos Laravel ni otros frameworks PHP.

## 2. Objetivo del proyecto

Los alumnos construirán una aplicación web denominada provisionalmente **Mi Asistente IA**, que permitirá conversar con un modelo de inteligencia artificial ejecutado mediante Ollama.

La aplicación tendrá una interfaz moderna, atractiva y responsive, similar a la de un asistente conversacional.

Debe ser un proyecto que motive a los alumnos porque podrán utilizar su propia aplicación para consultar dudas de programación, generar ejemplos y recibir explicaciones.

La IA se ejecutará en un servicio independiente y la aplicación PHP consumirá su API HTTP.

## 3. Tecnologías

Utilizaremos:

- PHP 8.4 o superior.
- HTML5.
- CSS.
- Tailwind CSS 4.
- DaisyUI 5.
- JavaScript únicamente cuando sea necesario.
- Docker y Docker Compose.
- Ollama como servidor de IA.
- Un modelo pequeño adecuado para equipos docentes.
- cURL para las peticiones HTTP.
- JSON para intercambiar información.
- Sesiones PHP para conservar conversaciones.

Prefiero utilizar componentes de DaisyUI y minimizar las clases de Tailwind.

No quiero HTML con decenas de clases utilitarias que dificulten su comprensión.

La interfaz debe ser elegante, clara, moderna y atractiva, pero su implementación debe seguir siendo comprensible para alumnos de FP.

Podemos utilizar una hoja CSS propia para los estilos específicos.

Justifica cualquier biblioteca o dependencia adicional antes de incorporarla.

## 4. Entregable A: enunciado completo para los alumnos

Necesito un enunciado detallado, redactado en español y preparado para incorporarlo a mis apuntes de VitePress.

Debe contener:

### 4.1. Presentación

- Título atractivo.
- Descripción del proyecto.
- Motivación y utilidad real.
- Objetivos de aprendizaje.
- Tecnologías utilizadas.
- Conocimientos previos.
- Duración estimada.
- Resultado final esperado.

Utiliza un lenguaje motivador, pero riguroso.

### 4.2. Explicación de la arquitectura

Explica cómo se relacionan:

1. Navegador del alumno.
2. Aplicación PHP.
3. API HTTP de Ollama.
4. Modelo de lenguaje.
5. Sesiones PHP.

Incluye diagramas de arquitectura y secuencia, preferentemente Mermaid, y propón imágenes didácticas cuando aporten valor.

Explica claramente que PHP consume una API, pero no ejecuta directamente el modelo de IA.

### 4.3. Requisitos funcionales

Desarrolla detalladamente los siguientes requisitos.

**RF1. Cliente básico de IA — Obligatorio**

- Mostrar un formulario para introducir preguntas.
- Validar la entrada.
- Enviar la pregunta mediante POST a PHP.
- Construir una petición HTTP hacia Ollama.
- Codificar los datos en JSON.
- Procesar la respuesta JSON.
- Mostrar la respuesta del modelo.
- Gestionar errores de conexión y respuestas incorrectas.
- Separar la lógica PHP de la presentación HTML.

**RF2. Configuración del asistente — Obligatorio**

- Seleccionar entre los modelos permitidos y disponibles.
- Configurar parámetros sencillos, como la longitud máxima de respuesta.
- Definir instrucciones de comportamiento para el asistente.
- Ofrecer varios perfiles, por ejemplo:
  - Tutor de PHP.
  - Experto en Docker.
  - Profesor de bases de datos.
  - Asistente general.
- Mostrar el modelo utilizado.
- Validar las opciones enviadas desde el formulario.

**RF3. Historial de conversaciones — Ampliación**

- Conservar preguntas y respuestas utilizando sesiones PHP.
- Mostrar el historial en formato conversacional.
- Permitir iniciar una nueva conversación.
- Mantener el contexto entre preguntas cuando corresponda.
- Diferenciar entre almacenar el historial visual y enviar el contexto al modelo.
- Establecer límites para evitar conversaciones excesivamente grandes.

Propón requisitos funcionales adicionales si mejoran el proyecto, pero distingue claramente entre obligatorios y ampliaciones.

Para cada requisito incluye:

- Descripción.
- Comportamiento esperado.
- Datos de entrada.
- Resultado esperado.
- Conceptos PHP necesarios.
- Criterios de aceptación.
- Posibles errores.
- Pruebas para verificar su funcionamiento.

### 4.4. Fases de desarrollo

Organiza la práctica en fases progresivas, de forma que el alumno obtenga resultados funcionales desde el principio.

Cada fase debe indicar:

- Objetivo.
- Trabajo que debe realizar.
- Conocimientos necesarios.
- Archivos implicados.
- Resultado verificable.
- Tiempo estimado.

No proporciones la solución completa dentro del enunciado.

### 4.5. Material visual

Quiero que el enunciado incluya imágenes cuando resulten útiles:

- Arquitectura de la aplicación.
- Comunicación HTTP.
- Ejemplo visual del chat.
- Configuración del asistente.
- Historial de conversación.

Distingue entre diagramas técnicos y mockups de interfaz.

Las imágenes deben ayudar a comprender el proyecto y despertar interés, no ser meramente decorativas.

Genera imágenes independientes cuando sea necesario.

### 4.6. Evaluación

Prepara una rúbrica de evaluación con criterios objetivos.

Valora especialmente:

- Funcionamiento.
- Uso correcto de PHP.
- Consumo de la API.
- Procesamiento de JSON.
- Organización del código.
- Gestión de errores.
- Calidad de la interfaz.
- Comprensión de la solución.

Distingue claramente los requisitos obligatorios de las ampliaciones.

## 5. Entregable B: plantillas de interfaz

Necesito plantillas HTML con Tailwind CSS y DaisyUI.

La interfaz debe incluir:

- Cabecera con nombre e identidad visual del asistente.
- Área principal de conversación.
- Mensajes diferenciados del usuario y de la IA.
- Formulario para introducir preguntas.
- Botón de envío.
- Indicador de procesamiento.
- Panel de configuración.
- Selector de perfil del asistente.
- Selector de modelo.
- Historial de conversación.
- Botón para iniciar una conversación nueva.
- Mensajes de error claros.

Debe funcionar correctamente en escritorio y móvil.

Quiero una estética moderna y cuidada, sin complejidad innecesaria.

Prioriza los componentes `card`, `chat`, `textarea`, `select`, `button`, `alert`, `loading` y otros componentes oficiales de DaisyUI.

Utiliza una hoja CSS propia cuando simplifique el código.

No mezcles la lógica de negocio con la presentación.

## 6. Entregable C: solución completa para el profesor

Implementa una solución funcional en PHP puro.

Propón una estructura de carpetas clara y proporcionada a la dificultad de la práctica.

Separa, cuando proceda:

- Controladores.
- Vistas.
- Servicios.
- Configuración.
- Funciones auxiliares.
- Recursos CSS y JavaScript.

Podemos utilizar clases para encapsular la comunicación con Ollama y funciones para operaciones sencillas.

No introduzcas una arquitectura MVC compleja ni patrones de diseño innecesarios.

La solución debe incluir:

- Todos los archivos completos.
- Explicación de las responsabilidades de cada archivo.
- Código comentado cuando aporte valor didáctico.
- Validaciones.
- Gestión de excepciones y errores.
- Uso correcto de sesiones.
- Configuración de la URL del servidor Ollama.
- Control de los modelos permitidos.
- Tiempos máximos de espera.
- Escape de la salida HTML para evitar XSS.
- Protección básica de los formularios y las peticiones.
- Tratamiento seguro de la respuesta del modelo.

Utiliza cURL de forma explícita para que los alumnos comprendan cómo se construye una petición HTTP.

Evita dependencias innecesarias.

## 7. Entregable D: infraestructura Docker

Prepara una infraestructura reproducible mediante Docker Compose.

Debe incluir:

- Servicio PHP con Apache.
- Extensión cURL.
- Servicio Ollama.
- Volúmenes necesarios.
- Red interna para comunicar los servicios.
- Configuración mediante variables de entorno cuando corresponda.
- Procedimiento para descargar el modelo.
- Comandos de arranque y parada.
- Comprobaciones de funcionamiento.
- Diagnóstico de problemas habituales.

La API de Ollama no debe exponerse públicamente sin controles de acceso.

Valora la posibilidad de utilizar un servidor Ollama común para toda la clase.

Explica las diferencias entre desplegar Ollama localmente y consumir una instancia compartida.

## 8. Entregable E: documentación para VitePress

El material docente se incorporará a mi web de apuntes VitePress.

Necesito Markdown crudo, preparado para copiar a los archivos `.md`.

Podemos utilizar:

- Bloques de código con resaltado de sintaxis.
- Tablas.
- Mermaid.
- Contenedores personalizados.
- Componentes Vue existentes.

No inventes componentes VitePress que no hayamos definido previamente.

Separa el material del alumno de la solución del profesor.

## 9. Metodología de trabajo

Quiero desarrollar el proyecto contigo paso a paso.

Seguiremos este orden:

1. Definir el alcance definitivo y la duración.
2. Diseñar la experiencia de usuario.
3. Crear mockups visuales.
4. Diseñar y validar la infraestructura Docker.
5. Probar la API de Ollama.
6. Implementar un cliente PHP mínimo.
7. Diseñar la estructura definitiva del proyecto.
8. Implementar los requisitos funcionales.
9. Preparar el enunciado detallado.
10. Preparar la solución del profesor.
11. Crear pruebas y rúbrica.
12. Preparar el material final para VitePress.

Antes de cada fase, explícame brevemente qué vamos a hacer y por qué.

No avances a la siguiente fase sin mi confirmación.

Si detectas una alternativa técnica o pedagógica mejor, propónla y justifícala.

**Empieza por la fase 1: analiza el alcance de la práctica, los requisitos, su dificultad y el tiempo necesario. Propón una planificación realista y espera mi aprobación antes de generar código.**

:::referencias
https://www.youtube.com/watch?v=aRuKmxMiRqo

:::