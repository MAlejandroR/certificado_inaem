---
title: Estructuras de control
description: Estructuras de control en PHP
date: 19/10/26
---

::: objetivos

* Repasar las estructuras de control de flujo de PHP.
* Conocer las estructuras de control de bucle y repetición.
* Aprender a utilizar las estructuras de control de flujo para tomar decisiones en el código.
* Aprender a utilizar las estructuras de control de bucle para repetir acciones.

::: 


## Estructuras de Control
* Las estructuras de control **determinan el flujo de ejecución de un programa**
- Especifican  el orden en que se ejecutarán las instrucciones.

  * Existen **tres tipos principales de estructuras de control**:
___


-  **Secuenciales**: Ejecutan las instrucciones en orden, una tras otra.
    

<figure style="text-align: center;">
  <img
    src="./images/secuenciales.png"
    alt="Diagrama de secuenciales"
    width="400"
  />
  <figcaption>
    Imagen generada con IA (OpenAI, ChatGPT).
  </figcaption>
</figure>

___

- **Selectivas**: Evalúan una condición que determina si ejecutar o una o varias  instrucciones
<figure style="text-align: center;">
  <table style="width: 100%; border-collapse: collapse;">
    <tr>
      <td style="width: 50%; text-align: center; vertical-align: middle;">
        <img
          src="./images/selectivo_if.png"
          alt="Diagrama de selección if"
          style="width: 100%; max-width: 500px;"
        />
      </td>
      <td style="width: 50%; text-align: center; vertical-align: middle;">
        <img
          src="./images/selectivo-if-else.png"
          alt="Diagrama de selección if-else"
          style="width: 100%; max-width: 500px;"
        />
      </td>
    </tr>
  </table>
  <figcaption>
    Imagen generada con IA (OpenAI, ChatGPT).
  </figcaption>
</figure>

___

- **Repetitivas**:Un bloque de instrucciones (una o más) será ejecutado  según una condición.

<figure style="text-align: center;">
  <img
    src="./images/repetitivas.png"
    alt="Diagrama de repetitivas"
    width="900"
  />
  <figcaption>
    Imagen generada con IA (OpenAI, ChatGPT).
  </figcaption>
</figure>


   ::: tip Teorema de Böhm-Jacopini (1966)
   En 1966, los matemáticos italianos **Corrado Böhm y Giuseppe Jacopini**
   demostr*aron que cualquier algoritmo computable puede expresarse
   utilizando únicamente tres estructuras de control:

Este resultado, conocido como el **teorema de Böhm-Jacopini**,
constituye uno de los fundamentos teóricos de la **programación estructurada**.

Gracias a estas tres estructuras podemos construir algoritmos
sin necesidad de recurrir a saltos incondicionales (`goto`).
:::

*Para implementarlas, necesitamos operadores y condiciones, cuya sintaxis vamos a ir estudiando.
