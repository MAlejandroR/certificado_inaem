---
title: Estructuras de control selectivas
description: Estructuras secuenciales, if, else, elseif, operador ternario, switch y match en PHP.
---

# Estructuras de control selectivas

*A modo de resumen, presentamos la siguiente tabla:

****Resumen de las estructuras de control****
