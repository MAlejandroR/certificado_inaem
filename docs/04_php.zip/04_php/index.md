---
title: PHP  WWW en nuettro entorno de trabajo
description: Introducción a qué es php
date: 27/9/26
---



# Sobre estos apuntes
Estos apuntes constituyen nuestro material de apoyo para el contenido de nuestro módulo.

Está realizado para aprender el lenguaje y aprender a desarrollar aplicaciones web

:::pageinfo Contenidos de los apuntes de esta web |fa-solid fa-book-open-reader
Los apuntes los he creado utilizando **referenicas web**, **mi propia experiencia como programador** y como **docente**  y, lógicamente,  en muchas ocasiones aclarando conceptos con **las IA**.

La IA se utiliza ***como herramienta de apoyo*** para contrastar conceptos, revisar explicaciones y corregir errores.

* El contenido que aquí se presentasn hay **no está escrito  por la IA**.

* La IA se ha utilizado y de forma intensa para revisar contenidos, correcciones ortográficas y de tipografía y en muchos casos aclarar conceptos y asegurar que están explicados de forma clara para aprenderlos con facilidad.
:::

# Cómo usar esta web

Realiza una lectura tranquila de los mismos, intento que no sean demasiado largos y agrupados por conceptos, intentando abordar cada uno de ellos (variables, funciones, arrays, ...)

:::definicion El aprendizaje de la programación no es lineal |fa-solid fa-route

En muchas ocasiones, ver o **practicar con  un concepto implica conocer otro que estudiaremos  más adelante**.

En estas frecuentes ocasiones, introduciremos lo  necesario para poder avanzar, y retomaremos  ese concepto cuando le corresponda,


::: 


:::definicion Comprender y Memorizar| fa-solid fa-brain
No trates de memoriazar los contenidos de esta web. 

Necesitamos conocer y comprender **conceptos**  para programar, pero programar no es una ciencia que se estudie con la memoria como otro tipo de ciencias.

Lo importante **es comprender los conceptos**, saberlos aplicar y resolver problemas como ya hemos introducido. 

La documentación y las herramientas de IA estarán disponibles en todo momento, , **pero no sustituyen tu comprensión ni tu criterio como programador**.

:::

:::definicion A programar se aprender programando|fa-solid fa-laptop-code

Practica los conceptos con los ejemplos que se plantean. **comenta cualquier cuestión que consideres**, conceptos que en clase se han explicado y aquí no aparecen o ideas que no terminen de quedar claras, cualquier cuestión que consideres

Tener errores o que no funionen los programas, es nuestra oportunidad para aprender. *Ver por qué no funciona es una oportunidad muy buena para poder comprender cómo hacer las cosas.*

Modifica los ejemplos, prueba alternativas, provoca errores e intenta comprender por qué se producen.

<Color> Aprender a interpretar y corregir errores es una de las habilidades más importantes de un programador.</Color>
:::

# Visualizando ejemplos

A lo largo de estos apuntes encontrarás ejemplos de código PHP que puedes **modificar y ejecutar directamente desde la página**.

Por ejemplo, una variable permite almacenar un valor:

<PhpRunner>

   ```php
   <?php
   $nombre = "Manuel";
   echo "Hola $nombre";
   ?>
   ```

</PhpRunner>

Para la exposición de los apuntes, se ha creado este componente llamdo PhpRunner para que los ejemplos que se muestran, se puedan ejecutar y modificar, viendo el resultado.

Su infraestructura está basado en <Color>docker</Color>. Por curiosidad realizo en la parte inferior una pequeña explicación, que cuando veas docker, podrán analizar y comprender


Puedes modificar el código anterior y pulsar **Ejecutar** para comprobar inmediatamente el resultado.

Si quieres volver al ejemplo original, utiliza el botón **Restaurar**.

:::definicion Visualización de la salida de PHP | fa-solid fa-eye

Nuestro ejecutor de PHP (**PhpRunner**) permite visualizar el resultado de ejecutar el código de dos maneras: <Color>Texto</Color> y <Color>HTML</Color>.

- **Vista <Color>Texto</Color>**: muestra la salida generada por PHP sin interpretarla como HTML.
  - Las etiquetas HTML se muestran literalmente.
  - Las secuencias de escape(https://inaem.certificadoweb.infenlaces.com/php/tipos/php/tipos-string/#_5-secuencias-de-escape), como `\n` (salto de línea) o `\t` (tabulación), son interpretadas por PHP cuando aparecen en cadenas entre comillas dobles.

- **Vista <Color>HTML</Color>**: interpreta la salida generada por PHP como contenido HTML y muestra el resultado tal como lo representaría un navegador.
  - Las etiquetas HTML se procesan y se aplican al contenido.
  - Los saltos de línea y espacios adicionales no suelen visualizarse, ya que HTML normalmente los agrupa.

**Importante:** PHP genera la misma salida en ambos casos. Lo que cambia es **cómo se visualiza esa salida**, no cómo se ejecuta el código.

:::

::: info Ejecución real de PHP
El código que escribes **no se simula en el navegador**.

Cuando pulsas **Ejecutar**, el código PHP se envía a un servidor, donde se ejecuta utilizando un **intérprete PHP real**.

El resultado de esa ejecución se devuelve al navegador y se muestra en el apartado **Salida**.

Esto permite experimentar con PHP de una forma muy similar a como se ejecutaría un fichero `.php` en un servidor.
:::

## ¿Cómo funciona?

Para ejecutar los ejemplos de forma controlada se utilizan varios contenedores Docker con responsabilidades diferentes.

```mermaid
flowchart LR
    A["🌐 Navegador<br>PhpRunner"]
    B["🐳 Nginx Proxy<br>HTTPS"]
    C["🐳 Web<br>ejecutar.php"]
    D["📁 Volumen<br>fichero temporal"]
    E["🐳 Sandbox<br>PHP"]

    A -->|"Código PHP"| B
    B -->|"Petición"| C
    C -->|"Guarda .php"| D
    C -->|"Solicita ejecución"| E
    D -->|"Lee .php"| E
    E -->|"Resultado / error"| C
    C -->|"JSON"| B
    B -->|"Respuesta"| A
```

De forma simplificada intervienen **tres contenedores principales**:

1. **Nginx Proxy**  
   Recibe las peticiones HTTPS realizadas desde los apuntes y las dirige al servicio correspondiente.

2. **Web**  
   Recibe el código enviado por `PhpRunner`, realiza las comprobaciones necesarias y crea un fichero PHP temporal.

3. **Sandbox**  
   Ejecuta el fichero utilizando un intérprete PHP real y devuelve el resultado de la ejecución.

El contenedor **Web** y el **Sandbox** comparten un volumen Docker que permite que el sandbox pueda leer el fichero PHP temporal generado para cada ejecución.

::: info Importante
El navegador **nunca ejecuta directamente PHP**.

PHP es un lenguaje que se ejecuta en el servidor. `PhpRunner` envía el código al servidor y posteriormente muestra en el navegador el resultado recibido.
:::

## Un entorno deliberadamente limitado

::: warning Entorno de prácticas
Este componente está diseñado para **aprender y probar pequeños fragmentos de PHP**, no para ejecutar cualquier programa PHP.

Por motivos de seguridad, la ejecución está limitada.

Determinadas funciones y operaciones pueden estar deshabilitadas y existen límites de tiempo, memoria, procesos y tamaño del código.

Por tanto, un programa PHP que funciona en un servidor convencional podría no estar permitido en este entorno.
:::

Estas restricciones son especialmente importantes porque el código introducido en el editor es **código proporcionado por el usuario que se ejecutará realmente en un servidor**.

El contenedor encargado de ejecutarlo funciona como un **sandbox** (entorno aislado), con permisos y recursos restringidos.

De esta forma podemos practicar de forma controlada con:

- variables y tipos de datos;
- operadores y expresiones;
- estructuras de control;
- bucles;
- funciones;
- arrays;
- objetos;
- y otros elementos del lenguaje PHP.

::: tip Objetivo
`PhpRunner` no pretende sustituir un entorno completo de desarrollo PHP.

Su objetivo es permitir **modificar un ejemplo, experimentar con él y observar inmediatamente qué ocurre** mientras estudiamos los diferentes conceptos del lenguaje.
:::